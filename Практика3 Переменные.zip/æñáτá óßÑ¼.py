t1 = 'Черешня'
t2 = 'Апельсины'
t3 = 'Бананы'
t4 = 'Яблоки'
pt1 = 35 #цена за кг
pt2 = 44 #цена за кг
pt3 = 18 #цена за кг
pt4 = 56 #цена за кг
vt1 = 4.5 #вес
vt2 = 1.6 #вес
vt3 = 2.4 #вес
vt4 = 3.3 #вес
D = 1000 #деньги
print('Чек:')
print(t1, vt1, str('кг.,'), pt1,str('р/кг,'), int(vt1*pt1), str('руб.'))
print(t2, vt2, str('кг.,'), pt2,str('р/кг,'), int(vt2*pt2), str('руб.'))
print(t3, vt3, str('кг.,'), pt3,str('р/кг,'), int(vt3*pt3), str('руб.'))
print(t4, vt4, str('кг.,'), pt4,str('р/кг,'), int(vt4*pt4), str('руб.'),'\nИтого:', float(pt1*vt1 + pt2*vt2 + pt3*vt3 + pt4 * vt4), '\nВнесено:', D, str('руб.'),'\nСдача:', float(D -(pt1*vt1 + pt2*vt2 + pt3*vt3 + pt4 * vt4)),str('руб.'))