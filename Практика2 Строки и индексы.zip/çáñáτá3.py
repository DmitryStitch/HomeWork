animal = 'кенгуру'
print(animal[4:7] + animal[0:4])