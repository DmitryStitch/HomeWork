name = 'нейропрограммирование'
print(len(name))
print(name[0:21:2], name[1:22:2])