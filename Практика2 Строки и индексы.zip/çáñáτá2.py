name = 'радар'
print(name[::-1])
name2 = 'норма'
print(name2[::-1])