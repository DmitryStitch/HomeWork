name = 'нейропластичность'
print(len(name))
print(name[15:0:-1])